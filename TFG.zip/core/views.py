from django.http import HttpResponse
from django.shortcuts import render


def funct(request, id):
    print ("recibido", id)
    siguiente = id+1
    #id += 1
    return render(request, "core/main.html", {'pregunta': id, 'siguiente': siguiente})#devuelve el template
# Create your views here.
def resultados(request):
    return HttpResponse("estos son los resultados")#devuelve en la pagina ese string

def calculo(id, respuesta):
    if(id==1):
        print("calculo de pregunta 1")
        return 4
    elif(id==2):
        print("calculo de pregunta 2")
    else:
        print("calculo de pregunta x")

