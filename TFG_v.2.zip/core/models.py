from django.db import models

# Create your models here.
class Pregunta(models.Model):
    pregunta= models.CharField(max_length=180)
    respuesta1= models.CharField(max_length=120)
    respuesta2= models.CharField(max_length=120)
    respuesta3= models.CharField(max_length=120)
    respuesta4= models.CharField(max_length=120)
    