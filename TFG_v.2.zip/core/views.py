from django.http import HttpResponse
from django.shortcuts import render

from .models import Pregunta
from .mach import modelo

#model= SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')

#print("Para que el modelo funcione correctamente tienes que respondes a las preguntas con frases y evitar los monosílabos")


def funct(request, id):
    pregunta = Pregunta.objects.filter(id=id).values()#devuelve un objeto, la fila de la base de datos
    pregunta = pregunta[0]["pregunta"]#le digo que me coja solo la parte de la pregunta de la base de datos
    siguiente = id+1
    #resultado = modelo(id, respuesta)
    #id += 1
    return render(request, "core/main.html", {'id': id, 'siguiente': siguiente, 'pregunta': pregunta})#devuelve el template
# Create your views here.
def resultados(request):

    return HttpResponse("estos son los resultados")#devuelve en la pagina ese string

def inicio(request):
    return render(request,"core/inicio.html")

